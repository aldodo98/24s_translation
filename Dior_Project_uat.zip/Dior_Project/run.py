from scrapy import cmdline

cmdline.execute('scrapy crawl GetTreeProductListTaskSpider'.split())